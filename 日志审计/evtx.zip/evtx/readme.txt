以管理员身份打开evtx.exe，即可在桌面看到导出的日志文件
其中包含：
Application.evtx
Microsoft-Windows-TerminalServices-LocalSessionManager%4Operational.evtx
Security.evtx
System.evtx