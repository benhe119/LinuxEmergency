import os 
import sys
import shutil
from win32com.shell import shell, shellcon

def GetDesktopPath():
    ilist =shell.SHGetSpecialFolderLocation(0, shellcon.CSIDL_DESKTOP)
    return shell.SHGetPathFromIDList(ilist)
desktop = GetDesktopPath()

new_path = os.path.join(desktop,'evtx')
if os.path.exists(new_path) == False:
	os.mkdir(new_path)

evtx_path = r'C:\Windows\System32\winevt\Logs'
evtx_list = ['Security.evtx','System.evtx','Microsoft-Windows-TerminalServices-LocalSessionManager%4Operational.evtx','Application.evtx','Microsoft-Windows-TerminalServices-RemoteConnectionManager%4Operational.evtx'] 
for root,path,filenames in os.walk(evtx_path):
	for filename in   filenames :
		for evtx in evtx_list:
			if filename.find(evtx) ==	0 :
				old_file = os.path.join(root,filename)
				new_file = os.path.join(new_path,filename)
				print old_file
				print new_file
				shutil.copyfile(old_file,new_file)